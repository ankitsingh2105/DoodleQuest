
// const backendLink = "http://localhost:8000";
const backendLink  = "https://doodlequest-7.onrender.com";
// const backendLink  = "https://doodlequest.duckdns.org/";
export default backendLink; 